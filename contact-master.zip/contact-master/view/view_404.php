<?php
    echo 'Passe t\'on chemin';
?>